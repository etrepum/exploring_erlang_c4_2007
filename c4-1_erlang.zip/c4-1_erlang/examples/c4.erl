-module(c4).
-export([hello_world/0]).

%% Call this with c4:hello_world().
hello_world() ->
    hello_world.
